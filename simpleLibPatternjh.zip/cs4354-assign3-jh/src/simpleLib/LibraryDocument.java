package simpleLib;

import java.util.Date;

public abstract class LibraryDocument  implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1989108431861126808L;
	String publisher;
	String title;
	Date publishDate;
	

}
