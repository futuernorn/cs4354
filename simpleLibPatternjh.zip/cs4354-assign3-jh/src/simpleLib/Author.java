package simpleLib;

public class Author {

}
