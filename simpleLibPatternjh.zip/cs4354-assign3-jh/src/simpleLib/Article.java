package simpleLib;

public class Article extends LibraryDocument {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5019098131132035363L;

}
